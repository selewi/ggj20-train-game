import * as Phaser from "phaser";
import { gameConfig } from "./gameConfig";

export const game = new Phaser.Game(gameConfig);
