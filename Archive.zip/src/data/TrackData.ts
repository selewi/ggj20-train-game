export interface TrackData {
  bpm: number;
  track: string;
  sections: string[];
}
